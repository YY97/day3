from django.apps import AppConfig


class CartappConfig(AppConfig):
    name = 'CartApp'
