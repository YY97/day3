from django.shortcuts import render

# Create your views here.
from MarketApp.models import Axffoodtype, AxfGoods


def market(request):
    typeid = request.GET.get('typeid', '104749')
    foodtypes = Axffoodtype.objects.all()

    # typeid,typename,childtypenames,typesort
    childtypenames = Axffoodtype.objects.filter(typeid=typeid)[0].childtypenames

    # 全部分类：０＃进口水果：１０３５３４＃国产水果：１０３５３３
    # print(childtypenames)

    childtype_list = childtypenames.split('#')
    # ['全部分类:0','进口水果:103534','国产水果:103533']
    # print(childtype_list)

    typename_list = []

    for childtype in childtype_list:
        typename = childtype.split(':')
        typename_list.append(typename)

    goods_list = AxfGoods.objects.filter(categoryid=typeid)

    childcid = request.GET.get('childcid', '0')

    if childcid == '0':
        pass
    else:
        goods_list = goods_list.filter(childcid=childcid)

    sort_rule_list = [
        ['综合排序', '0'],
        ['价格升序', '1'],
        ['价格降序', '2'],
        ['销量升序', '3'],
        ['销量降序', '4'],
    ]

    sort_rule = request.GET.get('sort_rule', '0')

    if sort_rule == '0':
        pass
    elif sort_rule == '1':
        goods_list = goods_list.order_by('price')
    elif sort_rule == '2':
        goods_list = goods_list.order_by('-price')
    elif sort_rule == '3':
        goods_list = goods_list.order_by('productnum')
    elif sort_rule == '4':
        goods_list = goods_list.order_by('-productnum')

    context = {
        'foodtypes': foodtypes,
        'good_list': goods_list,
        'typeid': typeid,
        'typename_list': typename_list,
        'childcid': childcid,
        'sort_rule_list':sort_rule_list,
        'sort_rule':sort_rule,
    }
    return render(request, 'axf/main/market/market.html', context=context)
