from django.db import models


# Create your models here.

# typeid,typename,childtypenames,typesort
class Axffoodtype(models.Model):
    typeid = models.CharField(max_length=32)
    typename = models.CharField(max_length=64)
    childtypenames = models.CharField(max_length=128)
    typesort = models.IntegerField()

    class Meta:
        db_table = 'axf_foodtype'


class AxfGoods(models.Model):
    productid = models.IntegerField()
    productimg = models.CharField(max_length=150)
    productname = models.CharField(max_length=50)
    productlongname = models.CharField(max_length=100)
    # 是否精选
    isxf = models.NullBooleanField(default=False)
    # 是否买一赠一
    pmdesc = models.NullBooleanField(default=False)
    # 规格
    specifics = models.CharField(max_length=20)
    # 价格
    price = models.IntegerField()
    # 超市价格
    marketprice = models.FloatField()
    # 组id
    categoryid = models.IntegerField()
    # 子类组id
    childcid = models.IntegerField()
    # 子类组名称
    childcidname = models.CharField(max_length=10)
    # 详情页id
    dealerid = models.IntegerField()
    # 库存
    storenums = models.IntegerField()
    # 销量
    productnum = models.IntegerField()

    class Meta:
        db_table = 'axf_goods'
