from django.apps import AppConfig


class MarketappConfig(AppConfig):
    name = 'MarketApp'
