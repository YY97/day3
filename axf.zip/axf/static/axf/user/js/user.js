$(function () {

    //  用户名的后台和前台验证验证
    $('#exampleInputName').blur(function () {
        //获取文本框中的内容
        // <div id ='a'><span>dfdfdsf</span></div>
        // html  <span>dfdfdsf</span>
        // text  dfdfdsf
        var name = $(this).val();

        // 校验文本框中的内容是否满足某条件
        var reg = /^[a-z]{3,6}$/;

        //test方法会判断某字符串是否符合某正则  如果符合返回的是true 如果不符合返回的就是false
        b = reg.test(name);

        if (b) {
            // $('#nameinfo').html('✔用户名字可以使用').css({'color':'green','font-size':10});
            //    $.getJson   $.get   $.POST  $.AJAX
            // $.getJSON(url,参数，function(data))

            $.getJSON('/axfuser/checkName/',
                {'name': name},
                function (data) {
                    if (data['status'] == 200) {
                        $('#nameinfo').html(data['msg']).css({'color': 'green', 'font-size': 10});
                    } else {
                        $('#nameinfo').html(data['msg']).css({'color': 'red', 'font-size': 10});

                    }
                })


        } else {
            $('#nameinfo').html('❌用户名字格式不正确').css({'color': 'red', 'font-size': 10});
        }

    })
    //密码一致性的校验
    $('#passwordconfirm').blur(function () {
        var password = $('#password').val();
        var passwordconfim = $(this).val();
        if (password == passwordconfim) {

        } else {
            $('#passwordinfo').html('密码不一致').css({'color': 'red', 'font-size': 10})
        }
    })
})


function parse1() {
    var password = document.getElementById('password').value;
    password = md5(password)

    document.getElementById('password').value = password


    return true
}